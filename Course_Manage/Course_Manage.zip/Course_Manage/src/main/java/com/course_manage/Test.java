package com.course_manage;
import com.course_manage.Mappers.CourseMapper;
import com.course_manage.Mappers.Select_CourseMapper;
import com.course_manage.entity.Course;
import com.course_manage.entity.Select_Course;
import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;
import org.springframework.beans.factory.annotation.Autowired;

import java.io.InputStream;
import java.util.List;

public class Test {
    private static Select_CourseMapper mapper;
            public static void main(String[] args) throws Exception {
                List<Select_Course> select_course = mapper.select();
                System.out.println(select_course);





    }
}
